<?php

session_start();
include("connection.php");
if(isset($_POST["bt3"]))
{
    $a=$_POST["srno"];
    $b=$_POST["res"];
    $c=$_POST["cus"];
    $d=$_POST["cont"];
    $e=$_POST["guest"];
    $f=$_POST["date"];
    $g=$_POST["time"];
    $sql1="DELETE FROM req_data WHERE srno='$a';";
    $sql1.="insert into accept_data (res_name,cus_name,cus_cont,no_guest,date,time) values ('$b','$c','$d','$e','$f','$g')";
    
    
    if(mysqli_multi_query($con,$sql1))
    {
     
      echo "<script type='text/javascript'>alert('Request Accpeted Successfully!');";
      echo "window.location.href = 'index.php';";
      echo "</script>";
    }
    else
    {
        echo "error";
    }
    
}
elseif(isset($_POST["bt"]))
{
    
    $a=$_POST["srno"];
    $b=$_POST["res"];
    $c=$_POST["cus"];
    $d=$_POST["cont"];
    $e=$_POST["guest"];
    $f=$_POST["date"];
    $g=$_POST["time"];
    $sql1="DELETE FROM req_data WHERE srno='$a';";
    $sql1.="insert into reject_data (res_name,cus_name,cus_cont,no_guest,date,time) values ('$b','$c','$d','$e','$f','$g')";
    
    
    
    if(mysqli_multi_query($con,$sql1))
    {
     
      echo "<script type='text/javascript'>alert('Rejected Successfully!');";
      echo "window.location.href = 'index.php';";
      echo "</script>";
    }
    else
    {
        echo "error";
    }
    
    
    
    
    
    
}

?>