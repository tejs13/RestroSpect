<?php

include("connection.php");
if(isset($_POST["bt"]))
{
    $b=$_POST["no"];
  
    $sql1="DELETE FROM req_data WHERE srno='$b'";
   
    
    
    if(mysqli_query($con,$sql1))
    {
     
      echo "<script type='text/javascript'>alert(Rejected Successfully!');";
      echo "window.location.href = 'index.php';";
      echo "</script>";
    }
    else
    {
        echo "error";
    }
    
}

?>